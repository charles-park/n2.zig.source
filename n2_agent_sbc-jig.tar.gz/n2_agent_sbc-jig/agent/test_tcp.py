import socket
import struct
from dataclasses import dataclass

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

host = socket.gethostname()
port = 9999

s.bind((host, port))

s.listen(5)

@dataclass
class Header:
    mode: str
    board: str
    cmd: str
    size_data: int
    def encode(self) -> bytearray:
        return f'{self.mode}{self.board}{self.cmd}'.encode()
        #return f'{self.mode}{self.board}{self.cmd}{self.size_data}'.encode()

hd = Header('AGENT', 'C4', 'RQ', 30)

@dataclass
class DATA:
    payload1: str
    payload2: str
    payload3: str

    def total_length(self) -> int:
        return len(self.payload1 + self.payload2 + self.payload3)

data = DATA('GPIO', 'GPX1', '1')
print(struct.pack('9sI', hd.encode(), hd.size_data))

print(struct.pack('9sI', hd.encode(), hd.size_data))



'''
while True:
    c, addr = s.accept()
    print("Got a connectino from %s" %str(addr))
    #c.send(struct.pack('5s2s2sI', msg.encode()))
    msg = c.recv(1024)
    print(msg.decode('ascii'))
    c.close()
'''


'''
client

import socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host = '192.168.30.220'
port = 9999

s.connect(host, port)
msg = s.recv(1024)
s.send("hello".encode('ascii'))
s.close()
print(msg.decode('ascii'))
'''
