from adc import ADC
import asyncio
from gpio import GPIO

async def read_gpio(adc):
    while True:
        #CEC
        #print(await adc._read(0x8, 0xf, ""))

        #HDMI_SCL
        #print(await adc._read(0x19, 0xf, ""))

        #HDMI_SDA
        #print(await adc._read(0x19, 0xb, ""))
        await asyncio.sleep(0.2)

def main():
    loop = asyncio.get_event_loop()
    adc = ADC(0)
    task0 = asyncio.ensure_future(read_gpio(adc))

    try:
        loop.run_forever()
    except KeyboardInterrupt:
        pass
    finally:
        task0.cancel()

if __name__ == "__main__":
    main()
