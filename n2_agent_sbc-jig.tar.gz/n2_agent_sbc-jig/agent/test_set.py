
err = ['usb3_lup_speed', 'usb3_ldown_speed', 'usb3_rup_speed', 'usb3_rdown_speed', 'usb3_lup_rw', 'usb3_ldown_rw', 'usb3_rup_rw', 'usb3_rdown_rw', 'usb3_lup_sdx', 'usb3_ldown_sdx', 'usb3_rup_sdx', 'usb3_rdown_sdx']

errs = set()

for i in err:
    errs.add(i[:i.find('_', 5)])
print(errs)
print(err)
