from gpio import GPIO
import asyncio
from asyncio import ensure_future as aef
from odroid_factory_api import API_MANAGER
from functools import wraps
from utils.log import init_logger
from copy import deepcopy
import time
import aiohttp
import os

from task import Component
from task import Task
from task import cancelled_exception
from label_printer import MacPrinter

FORUM = 'forum.odroid.com'

LOG = init_logger('', testing_mode='info')

class N2():
    lock_iperf = [0, 0]
    mac_printer = MacPrinter()
    def __init__(self):
        self.model = 'N2'
        self.api_manager = API_MANAGER(board='N2')
        self.pins = GPIO(self.model)
        self.gpios = self.pins.gpios
        self.pwrs = self.pins.pwrs
        self.fan = self.pins.fan
        self.led_sys = self.pins.led_sys
        self.led_pwr = self.pins.led_pwr
        self.led_eth = self.pins.led_eth
        self.hdmi = self.pins.hdmi
        self.sw_mem = True

        self.items = None
        self.flag0 = ['led_sys', 'led_eth', 'led_pwr', 'fan']
        self.flag1 = ['uart', 'usb2', 'onoff', 'gpio', 'usb_fw', 'hdmi',
                'mac_addr', 'ipaddr', 'usb3lup_speed', 'usb3ldown_speed',
                'usb3rup_speed', 'usb3rdown_speed', 'usb3lup_rw',
                'usb3ldown_rw', 'usb3rup_rw', 'usb3rdown_rw', 'finish',
                'adc0', 'adc3', 'usb3lup_sdx', 'usb3ldown_sdx', 'usb3rup_sdx',
                'usb3rdown_sdx', 'eth_speed', 'iperf', 'mem']
        self.items0 = {k:Component(flag_text=0) for k in self.flag0}
        self.items1  = {k:Component(flag_text=1) for k in self.flag1}
        self.items = {**self.items0, **self.items1}

        self.labels_gpio = [x.label for x in self.gpios]
        self.items_gpio = {k:Component(k) for k in self.labels_gpio}

        self.task_led_sys = Task(self.check_led_sys)
        self.task_led_eth = Task(self.check_led_eth)

        self.task_usb2 = Task(self.check_usb2, 30)
        self.task_usb3 = Task(self.check_usb3, 50)
        self.task_gpio = Task(self.check_gpio)
        self.task_eth_speed = Task(self.check_eth_speed, 30)
        self.task_gpio_hdmi = Task(self.check_gpio_hdmi)
        self.task_usb_fw = Task(self.check_usb_fw)
        self.task_mac_addr = Task(self.check_mac_addr)
        self.task_ipaddr = Task(self.check_ipaddr, 40)
        self.task_adc = Task(self.check_adc)
        self.task_fan = Task(self.check_fan)
        self.task_iperf = Task(self.check_iperf)
        self.task_mem = Task(self.check_mem)

    def init_item(self, item):
        for k, v in self.items.items():
            if k == item:
                if k == 'finish':
                    v.okay = 2
                    continue
                v.text = v.ack = v.ret = v.value = v.okay = None
                v.update = 1

    def init_variables(self):
        N2.lock_iperf[self.channel] = 0
        for k, v in self.items.items():
            if k == 'finish':
                v.okay = 2
                continue
            if k == 'uart' or k == 'onoff':
                continue
            v.text = v.ack = v.ret = v.value = v.okay = None
            if k == 'mem':
                v.text = '4G' if self.sw_mem else '2G'
            v.update = 1

    async def cancel_tasks(self):
        aef(self.task_led_sys.cancelled())
        aef(self.task_led_eth.cancelled())
        aef(self.task_usb2.cancelled())
        aef(self.task_usb3.cancelled())
        aef(self.task_gpio.cancelled())
        aef(self.task_eth_speed.cancelled())
        aef(self.task_gpio_hdmi.cancelled())
        aef(self.task_usb_fw.cancelled())
        aef(self.task_mac_addr.cancelled())
        aef(self.task_ipaddr.cancelled())
        aef(self.task_adc.cancelled())
        aef(self.task_fan.cancelled())
        aef(self.task_iperf.cancelled())
        aef(self.task_mem.cancelled())


    async def print_mac(self, mac):
        if mac.startswith('001e06'):
            if len(mac) == 12 and not ':' in mac:
                temp = [mac[i:i+2] for i in range(0, len(mac), 2)]
                mac = ':'.join(temp)
                self.mac_printer.label_print(self.channel, FORUM, mac)
                results = await self.api_manager.update_record({
                    'all_pass': True })
                return
        self.mac_printer.label_print(self.channel, "MAC Fail", "MAC Fail")
        results = await self.api_manager.update_record({
            'all_pass': False })

    async def print_label(self):
        _finish = deepcopy(self.items)
        del(_finish['finish'])
        finish1 = any(v.okay == None for k, v in _finish.items())
        finish2 = any(v.okay == 2 for k, v in _finish.items())
        finish = finish1 or finish2
        if finish != False:
            return

        err = set()
        for k, v in _finish.items():
            if v.okay != 1:
                err.add(k[:k.find('_', 5)])
        if len(err) > 0:
            tmp = ",".join(err)
            self.mac_printer.label_print(self.channel, tmp, None, 1)
            results = await self.api_manager.update_record({
                'all_pass': False })

    async def check_finish(self):
        if self.items['finish'].okay == 3:
            _finish = deepcopy(self.items)
            del(_finish['finish'])
            finish1 = any(v.okay == None for k, v in _finish.items())
            finish2 = any(v.okay == 2 for k, v in _finish.items())
            finish = finish1 or finish2
            if finish != False:
                return

            err = set()
            for k, v in _finish.items():
                if v.okay != 1:
                    err.add(k[:k.find('_', 5)])
            if len(err) > 0:
                self.fail_item('finish', 'FINISH')
                tmp = ",".join(err)
                results = await self.api_manager.update_record({
                    'all_pass': False })
            else:
                aef(self.uart.send('cmd,finish'))
                self.okay_item('finish', 'FINISH')

        if self.items['finish'].okay == 2:
            _finish = deepcopy(self.items)
            del(_finish['finish'])
            finish1 = any(v.okay == None for k, v in _finish.items())
            finish2 = any(v.okay == 2 for k, v in _finish.items())
            finish = finish1 or finish2
            if finish != False:
                return

            err = set()
            for k, v in _finish.items():
                if v.okay != 1:
                    err.add(k[:k.find('_', 5)])
            if len(err) > 0:
                '''
                self.fail_item('finish', 'FINISH')
                tmp = ",".join(err)
                self.mac_printer.label_print(self.channel, tmp, None, 1)
                results = await self.api_manager.update_record({
                    'all_pass': False })
                '''
            else:
                aef(self.uart.send('cmd,finish'))
                self.okay_item('finish', 'FINISH')
                await self.print_mac(self.items['mac_addr'].value[-12:])


    async def monitor_pwr(self):
        uart = None
        onoff = None
        async for _onoff in self.adc.check_pwr(self.pwrs):
            if uart != self.uart.uart['alive']:
                self.items['uart'].text = self.uart.uart['node']
                uart = self.items['uart'].okay = self.uart.uart['alive']
                self.items['uart'].update = 1

            if onoff != _onoff:
                onoff = self.items['onoff'].okay = _onoff
                if _onoff:
                    await self.init_sequence()
                    self.okay_item('onoff', 'ON')
                    self.ready_item('finish', 'FINISH', 2)
                else:
                    aef(self.cancel_tasks())
                    self.fail_item('onoff', 'OFF')
                    N2.lock_iperf[self.channel] = 0
            await self.check_finish()

    async def sequence_main(self):
        tasks = []
        while True:
            print(f'[[[[[ CH{self.channel} {self.seq_main} hello ]]]]]')
            if self.seq_main == 1:
                self.seq_main = 2
                #SD
                #tasks.append(aef(self.task_led_eth.run()))


                #stage 0
                try:
                    await self.task_ipaddr.run()
                    await self.task_mac_addr.run()
                except Exception as e:
                    print(f'task_ipaddr, task_mac_addr error {e}')
                tasks.append(aef(self.task_fan.run()))
                tasks.append(aef(self.task_gpio.run()))
                tasks.append(aef(self.task_adc.run()))
                tasks.append(aef(self.task_gpio_hdmi.run()))
                tasks.append(aef(self.task_usb3.run()))
                tasks.append(aef(self.task_eth_speed.run()))
                tasks.append(aef(self.task_usb_fw.run()))
                tasks.append(aef(self.task_usb2.run()))
                tasks.append(aef(self.task_led_sys.run()))
                tasks.append(aef(self.task_mem.run()))
                tasks.append(aef(self.task_iperf.run()))

            elif self.seq_main == 2:
                self.seq_main = 3
            elif self.seq_main == 3:
                flag = self.items['iperf'].okay
                if flag == 0 or flag == 1:
                    self.seq_main = 4
                    try:
                        await self.task_led_eth.run()
                    except Exception as e:
                        print(f'task_led_eth error {e}')
            await asyncio.sleep(1)


    @cancelled_exception()
    async def check_ipaddr(self, timeout):
        count = 0
        while count < timeout:
            self.items['ipaddr'].ack = None
            aef(self.uart.send('cmd,ipaddr'))
            ack = await self.wait_ack('ipaddr')
            if ack != 0:
                return
            ret = await self.wait_ret('ipaddr', 10)
            if ret != 0:
                return
            ipaddr = self.items['ipaddr'].value
            if ipaddr.startswith('192.168.'):
                self.okay_item('ipaddr', ipaddr)
                return
            count += 1
            await asyncio.sleep(1)
        self.fail_item('ipaddr', self.items['ipaddr'].value)

    @cancelled_exception()
    async def check_adc(self):
        self.items['adc0'].ack = None
        aef(self.uart.send('cmd,adc0'))
        ack = await self.wait_ack('adc0')
        if ack != 0:
            self.fail_item('adc3')
            return
        ret = await self.wait_ret('adc0', 10)
        if ret != 0:
            self.fail_item('adc3')
            return
        adc0 = self.items['adc0'].value
        volt_0 = 1.8*int(adc0)/4096
        if volt_0 > 1.1 and volt_0 < 1.5:
            self.okay_item('adc0', adc0)
        else:
            self.fail_item('adc0', adc0)
            self.fail_item('adc3')

        self.items['adc3'].ack = None
        aef(self.uart.send('cmd,adc3'))
        ack = await self.wait_ack('adc3')
        if ack != 0:
            return
        ret = await self.wait_ret('adc3', 10)
        if ret != 0:
            return
        adc3 = self.items['adc3'].value
        volt_3 = 1.8*int(adc3)/4096
        if volt_3 > 0.35 and volt_3 < 5.3:
            self.okay_item('adc3', adc3)
        else:
            self.fail_item('adc3', adc3)

    @cancelled_exception()
    async def check_iperf(self):
        self.items['iperf'].tmp = ""
        self.items['iperf'].update = 1
        self.ready_item('iperf', 'Waiting...', 2)
        cnt = 0
        while self.items['ipaddr'].okay != 1:
            if cnt > 30:
                self.fail_item('iperf', "ipaddr timeout")
                break
            cnt+= 1
            await asyncio.sleep(1)
        cnt = 0
        N2.lock_iperf[self.channel] = 0
        while any(N2.lock_iperf):
            if cnt > 40:
                self.fail_item('iperf', "lock timeout")
                return
            cnt += 1
            await asyncio.sleep(1)
        if cnt > 10:
            await asyncio.sleep(2)
        N2.lock_iperf[self.channel] = 1
        self.items['iperf'].ack = None
        aef(self.uart.send('cmd,iperf,192.168.0.3'))
        ack = await self.wait_ack('iperf')
        if ack != 0:
            N2.lock_iperf[self.channel] = 0
            return
        else:
            self.items['iperf'].tmp = ""
            self.items['iperf'].update = 1
            self.ready_item('iperf', 'Running...', 2)

        ret = await self.wait_ret('iperf', 30)
        if ret != 0:
            N2.lock_iperf[self.channel] = 0
            return
        if self.items['iperf'].value == "None":
            self.fail_item('iperf', "Fail")
            N2.lock_iperf[self.channel] = 0
            return

        _bandwidth = self.items['iperf'].value.split()
        _loss = self.items['iperf'].tmp[:-1]
        bandwidth = float(_bandwidth[0])
        loss = float(_loss)
        if _bandwidth[1][-4] == 'K':
            self.fail_item('iperf')
            results = await self.api_manager.update_record({
                'iperf_rx_udp_bandwidth': bandwidth,
                'iperf_rx_udp_loss_rate': loss})
            N2.lock_iperf[self.channel] = 0
            return
        if _bandwidth[1][-4] == 'G':
            self.fail_item('iperf')
            results = await self.api_manager.update_record({
                'iperf_rx_udp_bandwidth': bandwidth,
                'iperf_rx_udp_loss_rate': loss})
            N2.lock_iperf[self.channel] = 0
            return
        results = await self.api_manager.update_record({
            'iperf_rx_udp_bandwidth': bandwidth,
            'iperf_rx_udp_loss_rate': loss})
        if bandwidth > 800 and loss < 10:
            self.okay_item('iperf')
        else:
            self.fail_item('iperf')
        N2.lock_iperf[self.channel] = 0

    @cancelled_exception()
    async def check_mac_addr(self):
        cnt = 0
        while self.items['ipaddr'].okay != 1:
            if cnt > 10:
                break
            cnt += 1
            await asyncio.sleep(1)
        self.items['mac_addr'].ack = None
        aef(self.uart.send('cmd,mac_addr'))
        ack = await self.wait_ack('mac_addr')
        if ack != 0:
            return
        ret = await self.wait_ret('mac_addr', 10)
        if ret != 0:
            return

        mac_addr = self.items['mac_addr'].value[-12:]
        self.okay_item('mac_addr', mac_addr)
        if mac_addr.startswith('001e06'):
            self.api_manager.mac_addr = mac_addr
            self.api_manager.uuid_mac = self.items['mac_addr'].value
            await self.api_manager.update_record({
                'uuid': self.items['mac_addr'].value})
            self.okay_item('mac_addr', mac_addr)
            return
        else:
            self.fail_item('mac_addr')

        self.items['mac_addr'].ack = None
        mac_addr = await self.api_manager.request_mac_addr()
        aef(self.uart.send(f'cmd,mac_addr,{mac_addr}'))
        ack = await self.wait_ack('mac_addr')
        if ack != 0:
            return
        ret = await self.wait_ret('mac_addr', 15)
        if ret != 0:
            return

        #mac_addr = self.items['mac_addr'].value
        mac_addr = self.items['mac_addr'].value[-12:]
        self.okay_item('mac_addr', mac_addr)
        if mac_addr.startswith('001e06'):
            self.api_manager.mac_addr = mac_addr
            self.api_manager.uuid_mac = self.items['mac_addr'].value
            await self.api_manager.update_record({
                'uuid': self.items['mac_addr'].value})
            self.okay_item('mac_addr', mac_addr)
        else:
            self.fail_item('mac_addr')


    @cancelled_exception()
    async def check_usb2(self, timeout):
        while timeout:
            self.items['usb2'].ack = None
            aef(self.uart.send('cmd,usb2'))
            ack = await self.wait_ack('usb2')
            if ack != 0:
                return
            ret = await self.wait_ret('usb2')
            if ret != 0:
                return
            speed = self.items['usb2'].value
            if speed == '480' or speed == '12':
                self.okay_item('usb2', speed)
                return
            timeout -= 1
            await asyncio.sleep(1)
        self.fail_item('usb2')

    def init_usb3_items(self):
        items = ['usb3lup_speed', 'usb3ldown_speed', 'usb3rup_speed',
                'usb3rdown_speed', 'usb3lup_rw', 'usb3ldown_rw', 'usb3rup_rw',
                'usb3rdown_rw', 'usb3lup_sdx', 'usb3ldown_sdx', 'usb3rup_sdx',
                'usb3rdown_sdx']
        for item in items:
            self.items[item].value = None
            self.items[item].text = None
            self.items[item].ack = None
            self.items[item].okay = None
            self.items[item].update = 1

    @cancelled_exception()
    async def check_usb3(self, timeout):
        self.init_usb3_items()
        res = [self.usb3_speed(usb) for usb in ['lup', 'ldown', 'rup', 'rdown']]
        await asyncio.gather(*res)
        res = [self.usb3_sdx(usb) for usb in ['lup', 'ldown', 'rup', 'rdown']]
        await asyncio.gather(*res)

        self.items['usb3lup_rw'].ack = None
        aef(self.uart.send(f'cmd,usb3lup_rw,file'))
        ack = await self.wait_ack(f'usb3lup_rw')
        if ack != 0:
            return
        ret = await self.wait_ret(f'usb3lup_rw')
        if ret != 0:
            return
        err = self.items['usb3lup_rw'].value
        self.items['usb3lup_rw'].value = None
        if err != '0':
            self.fail_item('usb3lup_rw', 'File error')
            self.fail_item('usb3lup_down', 'File error')
            return

        #res = [self.usb3_rw(usb) for usb in ['lup', 'ldown', 'rup', 'rdown']]
        for label in ['lup', 'ldown', 'rup', 'rdown']:
            await self.usb3_rw(label)

    @cancelled_exception()
    async def usb3_speed(self, usb):
        self.items[f'usb3{usb}_speed'].ack = None
        aef(self.uart.send(f'cmd,usb3{usb}_speed'))
        ack = await self.wait_ack(f'usb3{usb}_speed')
        if ack != 0:
            return
        ret = await self.wait_ret(f'usb3{usb}_speed')
        if ret != 0:
            return

        speed = self.items[f'usb3{usb}_speed'].value
        self.items[f'usb3{usb}_speed'].text = speed
        if speed == '5000':
            self.okay_item(f'usb3{usb}_speed')
        else:
            self.fail_item(f'usb3{usb}_speed')

    @cancelled_exception()
    async def usb3_sdx(self, usb):
        self.items[f'usb3{usb}_sdx'].ack = None
        aef(self.uart.send(f'cmd,usb3{usb}_sdx'))
        ack = await self.wait_ack(f'usb3{usb}_sdx')
        if ack != 0:
            return
        ret = await self.wait_ret(f'usb3{usb}_sdx')
        if ret != 0:
            return

        sdx = self.items[f'usb3{usb}_sdx'].value
        self.items[f'usb3{usb}_sdx'].text = sdx
        if sdx.startswith('sd'):
            self.okay_item(f'usb3{usb}_sdx')
        else:
            self.fail_item(f'usb3{usb}_sdx')

    @cancelled_exception()
    async def usb3_rw(self, usb):
        self.items[f'usb3{usb}_rw'].ack = None
        sdx = self.items[f'usb3{usb}_sdx'].value
        if not sdx.startswith('sd'):
            self.fail_item(f'usb3{usb}_rw')
            return
        aef(self.uart.send(f'cmd,usb3{usb}_rw,check,{sdx}'))
        ack = await self.wait_ack(f'usb3{usb}_rw')
        if ack != 0:
            return
        ret = await self.wait_ret(f'usb3{usb}_rw')
        if ret != 0:
            return

        val = self.items[f'usb3{usb}_rw'].value
        if len(val) == 3 and type(val) == list:
            self.items[f'usb3{usb}_rw'].text = f'{val[0]},{val[1]},{val[2]}'
            if len(val[0]) == 1 or len(val[1]) == 1:
                self.fail_item(f'usb3{usb}_rw')
                return
            read = float(val[0][:-4])
            write = float(val[1][:-4])
            if read > 120 and write > 30:
                if val[2] != '0':
                    self.fail_item(f'usb3{usb}_rw')
                else:
                    self.okay_item(f'usb3{usb}_rw')
            else:
                self.fail_item(f'usb3{usb}_rw')
        else:
            self.fail_item(f'usb3{usb}_rw')

    @cancelled_exception()
    async def check_eth_speed(self, timeout):
        while timeout:
            self.items['eth_speed'].ack = None
            aef(self.uart.send('cmd,eth_speed'))
            ack = await self.wait_ack('eth_speed')
            if ack != 0:
                return
            ret = await self.wait_ret('eth_speed', 10)
            if ret != 0:
                return
            speed = self.items['eth_speed'].value
            if speed == '1000':
                self.okay_item('eth_speed', speed)
                return
            timeout -= 2
            await asyncio.sleep(2)
        self.fail_item('eth_speed', self.items['eth_speed'].value)

    @cancelled_exception()
    async def check_usb_fw(self):
        self.items['usb_fw'].ack = None
        aef(self.uart.send('cmd,usb_fw'))
        ack = await self.wait_ack('usb_fw')
        if ack != 0:
            return
        ret = await self.wait_ret('usb_fw', 50)
        if ret != 0:
            return
        ver = self.items['usb_fw'].value
        if ver == '9304':
            self.okay_item('usb_fw', ver)
        else:
            self.fail_item('usb_fw', ver)

    @cancelled_exception()
    async def check_mem(self):
        self.items['mem'].ack = None
        aef(self.uart.send(f'cmd,mem'))
        ack = await self.wait_ack('mem')
        if ack != 0:
            return
        ret = await self.wait_ret('mem', 5)
        if ret != 0:
            return

        mem = int(self.items['mem'].value)
        if self.sw_mem == True:
            if mem > 3600 and mem < 4000:
                self.okay_item('mem')
            else:
                self.fail_item('mem')
        else:
            if mem > 1800 and mem < 2500:
                self.okay_item('mem')
            else:
                self.fail_item('mem')

    @cancelled_exception()
    async def check_fan(self):
        self.okay_item('fan')
        return
        self.items['fan'].ack = None
        aef(self.uart.send(f'cmd,fan,0'))
        ack = await self.wait_ack('fan')
        if ack != 0:
            return
        ret = await self.wait_ret('fan', 5)
        if ret != 0:
            return
        if self.items['fan'].value != '0':
            self.fail_item('fan')
            return
        pin1, pin2 = [await self.adc.read_pin(pin) for pin in self.fan]
        if pin1 < 4 and pin2 < 1.5:
            self.fail_item('fan')
            return

        self.items['fan'].ack = None
        self.items['fan'].value = None
        aef(self.uart.send(f'cmd,fan,1'))
        ack = await self.wait_ack('fan')
        if ack != 0:
            return
        ret = await self.wait_ret('fan', 5)
        if ret != 0:
            return
        if self.items['fan'].value != '0':
            self.fail_item('fan')
            return
        pin1, pin2 = [await self.adc.read_pin(pin) for pin in self.fan]
        if pin1 < 4 and pin2 > 0.5:
            self.fail_item('fan')
            return
        else:
            self.okay_item('fan')

    @cancelled_exception()
    async def check_gpio_hdmi(self):
        self.ready_item('hdmi', 'Testing...', 2)
        defects = set()

        self.items['hdmi'].ack = None
        aef(self.uart.send(f'cmd,hdmi,0'))
        ack = await self.wait_ack('hdmi')
        if ack != 0:
            return
        ret = await self.wait_ret('hdmi', 5)
        if ret != 0:
            return

        ret = await self.adc.read_pin_hdmi(self.hdmi, 0)
        if ret != 0:
            defects.update(ret)

        self.items['hdmi'].ack = None
        aef(self.uart.send(f'cmd,hdmi,1'))
        ack = await self.wait_ack('hdmi')
        if ack != 0:
            return
        ret = await self.wait_ret('hdmi', 5)
        if ret != 0:
            return

        ret = await self.adc.read_pin_hdmi(self.hdmi, 1)
        if ret != 0:
            defects.update(ret)

        self.items['hdmi'].ack = None
        aef(self.uart.send(f'cmd,hdmi,2'))
        ack = await self.wait_ack('hdmi')
        if ack != 0:
            return
        ret = await self.wait_ret('hdmi', 5)
        if ret != 0:
            return

        ret = await self.adc.read_pin_hdmi(self.hdmi, 2)
        if ret != 0:
            defects.update(ret)
        if len(defects) != 0:
            self.fail_item('hdmi', ' '.join(defects))
            return
        self.okay_item('hdmi', 'OK')


    @cancelled_exception()
    async def check_gpio(self):
        self.ready_item('gpio', 'Testing...', 2)
        defects = set()

        gpios = deepcopy(self.gpios)
        for i in self.items_gpio:
            self.items['gpio'].ack = None
            aef(self.uart.send(f'cmd,gpio,{i}'))
            ack = await self.wait_ack('gpio')
            if ack != 0:
                return
            ret = await self.wait_ret('gpio', 5)
            if ret != 0:
                return
            result = await self.adc.read_times(gpios, i)
            if result != 0:
                self.items_gpio[i].okay = 0
                defects.update(result)
                LOG.error(f'{result}')
                for i in result:
                    for idx, j in enumerate(gpios):
                        if i == j.label:
                            del(gpios[idx])
            elif result == 0:
                self.items_gpio[i].okay = 1
        if all(v.okay for k, v in self.items_gpio.items()):
            self.okay_item('gpio', 'OK')
        else:
            self.fail_item('gpio', ','.join(defects))

    def init_eth_items(self):
        self.items['led_eth'].value = None
        self.items['led_eth'].text = None
        self.items['led_eth'].ack = None
        self.items['led_eth'].okay = None
        self.items['led_eth'].update = 1

    @cancelled_exception()
    async def check_led_eth(self):
        self.init_eth_items()
        self.items['led_eth'].ack = None
        aef(self.uart.send('cmd,led_eth,1000'))
        ack = await self.wait_ack('led_eth')
        if ack != 0:
            aef(self.uart.send('cmd,led_eth,1000'))
            return
        ret = await self.wait_ret('led_eth', 15)
        if ret != 0:
            aef(self.uart.send('cmd,led_eth,1000'))
            return

        if self.items['led_eth'].value != '0':
            self.fail_item('led_eth')
            return
        ret = await self.adc.check_led_eth(self.led_eth, mode=1000)
        if ret != 0:
            self.fail_item('led_eth')
            aef(self.uart.send('cmd,led_eth,1000'))
            return

        self.items['led_eth'].ack = None
        self.items['led_eth'].value = None
        aef(self.uart.send('cmd,led_eth,100'))
        ack = await self.wait_ack('led_eth')
        if ack != 0:
            aef(self.uart.send('cmd,led_eth,1000'))
            return
        ret = await self.wait_ret('led_eth', 15)
        if ret != 0:
            aef(self.uart.send('cmd,led_eth,1000'))
            return

        if self.items['led_eth'].value != '0':
            self.fail_item('led_eth')
            aef(self.uart.send('cmd,led_eth,1000'))
            return
        ret = await self.adc.check_led_eth(self.led_eth, mode=100)
        if ret != 0:
            self.fail_item('led_eth')
            aef(self.uart.send('cmd,led_eth,1000'))
            return
        else:
            self.okay_item('led_eth')
        aef(self.uart.send('cmd,led_eth,1000'))

    @cancelled_exception()
    async def check_led_sys(self):
        ret = await self.adc.check_led(self.led_pwr, onoff=1)
        if ret == 0:
            self.okay_item('led_pwr')
        else:
            self.fail_item('led_pwr')

        self.items['led_sys'].ack = None
        aef(self.uart.send('cmd,led_sys,0'))
        ack = await self.wait_ack('led_sys')
        if ack != 0:
            return
        ret = await self.wait_ret('led_sys', 10)
        if ret != 0:
            return

        if self.items['led_sys'].value != '0':
            self.fail_item('led_sys')
            return

        ret = await self.adc.check_led(self.led_sys, onoff=0)
        if ret != 0:
            self.fail_item('led_sys')
            return

        self.items['led_sys'].ack = None
        aef(self.uart.send('cmd,led_sys,1'))
        ack = await self.wait_ack('led_sys', 5)
        if ack != 0:
            return
        ret = await self.wait_ret('led_sys', 10)
        if ret != 0:
            return
        if self.items['led_sys'].value != '0':
            self.fail_item('led_sys')
            return

        ret = await self.adc.check_led(self.led_sys, onoff=1)
        if ret != 0:
            self.fail_item('led_sys')
            return
        else:
            self.okay_item('led_sys')

