from gpio.pin import *

gpx17 = Pin(0x9, 0x8, 'PIN3')
gpx18 = Pin(0x9, 0xc, 'PIN5')
gpa13 = Pin(0x9, 0x9, 'PIN7')
gpx12 = Pin(0x9, 0xd, 'PIN8')
gpx13 = Pin(0x9, 0xa, 'PIN10')
gpx3 = Pin(0x9, 0xe, 'PIN11')
gpx16 = Pin(0x9, 0xb, 'PIN12')
gpx4 = Pin(0x9, 0xf, 'PIN13')

gpx7 = Pin(0xa, 0x8, 'PIN15')
gpx0 = Pin(0xa, 0xc, 'PIN16')
gpx1 = Pin(0xa, 0x9, 'PIN18')
gpx8 = Pin(0xa, 0xd, 'PIN19')
gpx9 = Pin(0xa, 0xa, 'PIN21')
gpx2 = Pin(0xa, 0xe, 'PIN22')
gpx11 = Pin(0xa, 0xb, 'PIN23')
gpx10 = Pin(0xa, 0xf, 'PIN24')

gpa4 = Pin(0xb, 0x8, 'PIN26')
gpa14 = Pin(0xb, 0xc, 'PIN27')
gpa15 = Pin(0xb, 0x9, 'PIN28')
gpx14 = Pin(0xb, 0xd, 'PIN29')
gpx15 = Pin(0xb, 0xa, 'PIN31')
gpa12 = Pin(0xb, 0xe, 'PIN32')
gpx5 = Pin(0xb, 0xb, 'PIN33')
gpx6 = Pin(0xb, 0xf, 'PIN35')

gpx19 = Pin(0x18, 0x8, 'PIN36')
gpa11 = Pin(0x18, 0xc, 'J7_PIN2')
gpa0 = Pin(0x18, 0x9, 'J7_PIN4')
gpa2 = Pin(0x18, 0xd, 'J7_PIN5')
gpa1 = Pin(0x18, 0xa, 'J7_PIN6')
gpa3 = Pin(0x18, 0xe, 'J7_PIN7')

V3_0 = Pin(0x8, 0x8, 'V3_0')
V5_0 = Pin(0x8, 0xc, 'V5_0')
V5_1 = Pin(0x8, 0x9, 'V5_1')
V3_1 = Pin(0x8, 0xd, 'V3_1')
V5_2 = Pin(0x8, 0xe, 'V5_2')

GPIOS_N2 = [gpx17, gpx18, gpa13, gpx12, gpx13, gpx3, gpx16, gpx4, gpx7, gpx0,
        gpx1, gpx8, gpx9, gpx2, gpx11, gpx10, gpa4, gpa14, gpa15, gpx14, gpx15,
        gpa12, gpx5, gpx6, gpx19, gpa11, gpa0, gpa2, gpa1, gpa3]

LED_SYS_N2 = Pin(0x19, 0xa, 'LED_SYS', high=0.6, low=0.1)
LED_PWR_N2 = Pin(0x19, 0xe, 'LED_PWR', high=0.6, low=0.1)

LED_ETH_Y_N2 = Pin(0x19, 0xc, "ETH_Y", high=0.6, low=0.1)
LED_ETH_G_N2 = Pin(0x19, 0x8, "ETH_G", high=0.3, low=0.1)

PWRS_N2 = [V3_0, V5_0, V5_1, V3_1, V5_2]
#PWRS_N2 = [V5_2]
LED_ETH_N2 = [LED_ETH_Y_N2, LED_ETH_G_N2]
