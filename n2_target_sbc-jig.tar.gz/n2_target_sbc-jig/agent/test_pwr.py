from adc import ADC
import asyncio
from gpio import GPIO
import logging

logger = logging.getLogger('adc')
logger.setLevel(logging.DEBUG)

pins = GPIO('N2')
gpios = pins.gpios
pwrs = pins.pwrs

async def read_gpio(adc):
    while True:
        off = await adc.read_power(pwrs)
        await asyncio.sleep(1)

def main():
    loop = asyncio.get_event_loop()
    adc = ADC(1)
    task0 = asyncio.ensure_future(read_gpio(adc))

    try:
        loop.run_forever()
    except KeyboardInterrupt:
        pass
    finally:
        task0.cancel()

if __name__ == "__main__":
    main()
