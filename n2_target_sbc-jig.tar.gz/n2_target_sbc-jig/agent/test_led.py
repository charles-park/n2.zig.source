from adc import ADC
import asyncio
from gpio import GPIO

async def read_gpio(adc):
    while True:
        # LED_ETH_Y
        print(await adc._read(0x19, 0xc, "ETH_Y"))
        # LED_ETH_G
        print(await adc._read(0x19, 0x8, "ETH_G"))

        # LED_SYS
        #print(await adc._read(0x19, 0xa, "LED_SYS"))
        # LED_PWR
        #print(await adc._read(0x19, 0xe, "LED_PWR"))
        await asyncio.sleep(0.2)

def main():
    loop = asyncio.get_event_loop()
    adc = ADC(1)
    task0 = asyncio.ensure_future(read_gpio(adc))

    try:
        loop.run_forever()
    except KeyboardInterrupt:
        pass
    finally:
        task0.cancel()

if __name__ == "__main__":
    main()
